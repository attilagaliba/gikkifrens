"use client";
import { Grid, Box } from "@mui/material";
import PageContainer from "@/app/(DashboardLayout)/components/container/PageContainer";
// components
import SalesOverview from "@/app/(DashboardLayout)/components/dashboard/SalesOverview";
import YearlyBreakup from "@/app/(DashboardLayout)/components/dashboard/YearlyBreakup";
import RecentTransactions from "@/app/(DashboardLayout)/components/dashboard/RecentTransactions";
import ProductPerformance from "@/app/(DashboardLayout)/components/dashboard/ProductPerformance";
import Blog from "@/app/(DashboardLayout)/components/dashboard/Blog";
import MonthlyEarnings from "@/app/(DashboardLayout)/components/dashboard/MonthlyEarnings";

const Dashboard = () => {

  const userData = {
    userFid: 474817,
    userDisplayName: `attilagaliba`,
    userPfp: `https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/df368ec8-99d7-4485-b261-9cd4efd8f200/original`,
    userBalance: 1814.237847,
    userAlfaBalance: 0,
    userAlfaClaimable: 28.602736,
    userSubs: 30,
    userSubsCost: 19500,
    userDailyAlfa: 218.23,
    userStakes: 8,
    userStakedAlfa: 2699.23,
    userStakeCashback: 19066,
    userChannelSubs: 53,
    userChannelEarnings: 6625,
  };

  const userSubs = [
    {
      userDisplayName: 'Chef 🎩',
      userPfp: 'https://i.imgur.com/zpASdSb.png',
      userChannelAlfa: 256.23,
      userChannelCost: 1000,
    },{
      userDisplayName: 'mingbada🎩',
      userPfp: 'https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/c1d1b67a-b386-4452-51ef-c57c7c510700/rectcrop3',
      userChannelAlfa: 165,
      userChannelCost: 500,
    },
    {
      userDisplayName: '🃏agusti 🔷🐘',
      userPfp: 'https://i.imgur.com/HRs0nGc.jpeg',
      userChannelAlfa: 430,
      userChannelCost: 1500,
    },
    {
      userDisplayName: 'hoshino🎩⚪️🔵🟡🃏',
      userPfp: 'https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/b8994e49-6170-4d0a-de86-843e7327fb00/original',
      userChannelAlfa: 138.65,
      userChannelCost: 500,
    },{
      userDisplayName: 'ggang',
      userPfp: 'https://imagedelivery.net/BXluQx4ige9GuW0Ia56BHw/463b50d3-600b-4802-d8f1-336c4838b300/rectcrop3',
      userChannelAlfa: 201,
      userChannelCost: 500,
    },
  ]

  return (
    <PageContainer title="Dashboard" description="this is Dashboard">
      <Box>
        <Grid container spacing={3}>
          <Grid item xs={12} lg={4}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <MonthlyEarnings userData={userData} />
              </Grid>
              <Grid item xs={12}>
                <YearlyBreakup userData={userData} />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} lg={8}>
            <ProductPerformance userSubs={userSubs} />
          </Grid>
          <Grid item xs={12} lg={4}>
            <RecentTransactions />
          </Grid>
          <Grid item xs={12} lg={8}>
            <ProductPerformance userSubs={userSubs} />
          </Grid>
          <Grid item xs={12}>
            <Blog />
          </Grid>
        </Grid>
      </Box>
    </PageContainer>
  );
};

export default Dashboard;
